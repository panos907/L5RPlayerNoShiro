package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    //This button is used to start the InputActivity
    public void onButtonClick(android.view.View view) {
        startActivity(new Intent(MainActivity.this, InputActivity.class));
    }
    //This button is used to start the HistoryActivity
    public void onHisButtonClick(android.view.View view) {
        startActivity(new Intent(MainActivity.this, HistoryActivity.class));
    }
}
