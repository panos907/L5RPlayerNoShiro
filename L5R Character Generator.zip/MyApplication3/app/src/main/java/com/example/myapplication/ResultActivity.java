package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class ResultActivity extends AppCompatActivity {

    private Object view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    //We initialize an array that maps each image to the corresponding position of the character's clan & school in the string-array "clan_school" string resource.
        final Integer[] Icons = new Integer[]{
                R.drawable.crab_hida,
                R.drawable.crab_hiruma,
                R.drawable.crab_kuni,
                R.drawable.crab_yasuki,
                R.drawable.crane_daidoji,
                R.drawable.crane_doji,
                R.drawable.crane_asahina,
                R.drawable.crane_kakita,
                R.drawable.unicorn_ide,
                R.drawable.unicorn_moto,
                R.drawable.unicorn_shinjob,
                R.drawable.unicorn_shinjoc,
                R.drawable.unicorn_utaku,
                R.drawable.unicorn_iuchi,
                R.drawable.mantis_yoritomob,
                R.drawable.mantis_tsuruchi,
                R.drawable.mantis_yoritomoc,
                R.drawable.mantis_moshi,
                R.drawable.scorpion_bayushib,
                R.drawable.scorpion_yogo,
                R.drawable.scorpion_bayushic,
                R.drawable.scorpion_shosuro,
                R.drawable.dragon_mirumoto,
                R.drawable.dragon_agasha,
                R.drawable.dragon_kitsuki,
                R.drawable.togashi,
                R.drawable.phoenix_shiba,
                R.drawable.phoenix_isawa,
                R.drawable.phoenix_asako,
                R.drawable.lion_akodo,
                R.drawable.lion_matsu,
                R.drawable.lion_ikoma,
                R.drawable.lion_kitsu,
        };

    //We initialize all objects to be used in the code below.
        TextView myview = findViewById(R.id.nameout);
        TextView resultview = findViewById(R.id.result);
        TextView nameview = findViewById(R.id.resultname);
        ImageView avatar = findViewById(R.id.avatar);
        Drawable d;
        charData newdata;
        DataBaseHelper helper= new DataBaseHelper(ResultActivity.this);


        //We initialize some needed string arrays that will help us generate the clan_school and name of the character.
        String[] character = getResources().getStringArray(R.array.clan_and_school);
        String[] male=getResources().getStringArray(R.array.male_names);
        String[] female=getResources().getStringArray(R.array.female_names);
        String charname;
       //We extract the necessary info passed from the fields of InputActivity
        String name = getIntent().getExtras().getString("name");
        String gender= getIntent().getExtras().getString("gender");
        String temp= nameview.getText().toString();
       //And then set the player's name accordingly.
        myview.setText(name);

        //We generate a random clan_school combination from the characters array
        Random rand = new Random();
        int mynum = rand.nextInt(character.length);
        resultview.setText(character[mynum]);



        //We select a random character name based on the gender the user selected in the InputActivity
        if (gender.equals("Male")){
            int namenum= rand.nextInt(male.length);
            nameview.setText(temp + male[namenum]);
            charname=male[namenum];
        }
        else {
            int namenum= rand.nextInt(male.length);
            nameview.setText(temp + female[namenum]);
            charname=female[namenum];
        }

        //And then generate the specific image of the clan_school combination based on the Icons array.
        if (mynum <= Icons.length - 1) {
            d = getResources().getDrawable(Icons[mynum]);
            avatar.setImageDrawable(d);
        }
        //We save the generated name and clan & school combination to the charData object so that it can be inserted into the database.
            try {
                newdata= new charData(resultview.getText().toString(),charname);
                Toast.makeText(ResultActivity.this,"Character Saved!",Toast.LENGTH_SHORT).show();
            }
            catch(Exception e) {
                newdata = new charData("error","data_not_added");
                Toast.makeText(ResultActivity.this,newdata.getName(),Toast.LENGTH_SHORT).show();
            }
        boolean sucess = helper.addOne(newdata);
        if (helper.getEveryone().size()>10){
            boolean del=helper.deleteOne();
        }



    }

}
