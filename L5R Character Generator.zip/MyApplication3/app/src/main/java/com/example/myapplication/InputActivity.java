package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;


public class InputActivity extends AppCompatActivity {

    EditText edt;
    String st,ge,temp;
    RadioGroup radioSexGroup;
    RadioButton radioSexButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        radioSexGroup=(RadioGroup)findViewById(R.id.radioGroup);
        edt= findViewById(R.id.charname);

    }



    public void onButtonClick(android.view.View view) {
        Intent myintent = new Intent(InputActivity.this, ResultActivity.class);
        //We prepare the user's input data to be passed to the next activity
        st = edt.getText().toString();
        int selected=radioSexGroup.getCheckedRadioButtonId();
        if (selected!=-1){
            radioSexButton=(RadioButton)findViewById(selected);
            ge=radioSexButton.getText().toString();
            myintent.putExtra("gender", ge);
        }
        //If the user did not select a gender, we assume it is male.
        //NOTE: This part needs to be turned into random gender selection.
        else{

            myintent.putExtra("gender", "Male");
        }

        //Data to be passed is saved in intent
        myintent.putExtra("name", st);
        //And then we start the next activity
        startActivity(myintent);
    }

}
