package com.example.myapplication;

public class charData {
    private String name;
    private String clan_school;

    public charData(String clan_school,String name) {
        this.clan_school = clan_school;
        this.name=name;
    }

    public charData() {
    }

    public String getName() {
        return name;
    }

    public String getClan_school() {
        return clan_school;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setClan_school(String clan_school) {
        this.clan_school = clan_school;
    }

    @Override
    public String toString() {
        return "HistoryData{" +
                "name='" + name + '\'' +
                ", clan_school='" + clan_school + '\'' +
                '}';
    }
}
