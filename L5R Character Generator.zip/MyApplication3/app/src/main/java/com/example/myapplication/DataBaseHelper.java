package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;


public class DataBaseHelper<context> extends SQLiteOpenHelper {

    public static final String CHARACTERS="CHARACTERS";
    public static final String COLUMN_NAME = "NAME";
    public static final String COLUMN_CLAN_SCHOOL = "CLAN_SCHOOL ";
    public static final String COLUMN_ID = "ID";


    public DataBaseHelper(@Nullable Context context) {
        super(context,"history.db",null,1);
    }


    //This is called the first time the database is created.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement= "CREATE TABLE " + CHARACTERS + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_NAME + " TEXT, " + COLUMN_CLAN_SCHOOL + "TEXT )";
        db.execSQL(createTableStatement);
    }

    //This is called if the database version number changes.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addOne(charData inputdata) {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv= new ContentValues();

        cv.put(COLUMN_NAME,inputdata.getName());
        cv.put(COLUMN_CLAN_SCHOOL,inputdata.getClan_school());

        long insert= db.insert(CHARACTERS,null,cv);
        if (insert == -1) {
            db.close();
            return false;
        }
        else {
            db.close();
            return true;
        }
    }
    //This method is used to SELECT all character data from the database and returns a list of charData objects with each generated character.
    public List<charData> getEveryone(){
        List<charData> returnList= new ArrayList<>();
        String querystring="SELECT * FROM "+CHARACTERS;
        SQLiteDatabase db=this.getReadableDatabase();

        Cursor cursor = db.rawQuery(querystring,null);
        if (cursor.moveToFirst()){
            do{
                int charID=cursor.getInt(0);
                String name=cursor.getString(1);
                String clan=cursor.getString(2);

                charData mydata= new charData(clan,name);
                returnList.add(mydata);
            } while(cursor.moveToNext());
        }
        else{
            //failure, do not add anything to the list
        }
        cursor.close();
        db.close();
        return returnList;
    }

    public boolean deleteOne(){
        SQLiteDatabase db=this.getWritableDatabase();
        String deletequery="DELETE FROM "+CHARACTERS+" WHERE "+COLUMN_ID+" =(SELECT MIN("+COLUMN_ID+") FROM "+CHARACTERS+")";
        db.execSQL(deletequery);
        return true;
    }
}

