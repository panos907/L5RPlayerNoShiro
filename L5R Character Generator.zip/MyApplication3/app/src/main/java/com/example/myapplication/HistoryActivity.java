package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    //As soon as the activity begins, we query the database and display the data on the ListView.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        ListView history=  findViewById(R.id.hisview);
        List<String> fildata=new ArrayList<>(6);
        String tobefilled,tobefilled2;


        //We add some initial data we'd like to be displayed in the activity, the column names and sorting description
        fildata.add("Sorted by Oldest to Newest Added");
        fildata.add("Name"+"            "+"Clan and School");
        fildata.add("");

        //We query the database and get all data to be displayed inside a list of charData objects.
        DataBaseHelper helper= new DataBaseHelper(HistoryActivity.this);
        List<charData> data= helper.getEveryone();
        System.out.println(data.size());

        for (int i=0;i<data.size();i++){
            //We filter the data by cutting out the Clan and School Strings to make a cleaner visual presentation.
            tobefilled=data.get(i).getClan_school().replace("Clan:","");
            tobefilled2=tobefilled.replace("School","");

            //We then add the filtered string to the list of Strings to be displayed on the ListView
            fildata.add(data.get(i).getName()+"            "+ tobefilled2);
        }

        ArrayAdapter adapter= new ArrayAdapter<String>(HistoryActivity.this, android.R.layout.simple_list_item_1,fildata);
        history.setAdapter(adapter);

    }



}